﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using PraksaProjekatAPI.Services;
using ErrorLoggingService = PraksaProjekatAPI.Services.ErrorLoggingService;

namespace PraksaProjekatAPI.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class BannerCompanyController : ControllerBase
    {
        private readonly IBannerCompanyRepository _bannerCompanyRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<BannerCompanyController> _logger;
        private readonly ErrorLoggingService _errorLoggingService;

        public BannerCompanyController(IBannerCompanyRepository bannerCompanyRepository, IMapper mapper, ILogger<BannerCompanyController> logger, ErrorLoggingService errorLoggingService)
        {
            _bannerCompanyRepository = bannerCompanyRepository;
            _mapper = mapper;
            _logger = logger;
            _errorLoggingService = errorLoggingService;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<BannerCompany>))]
        public IActionResult GetBannerCompanies()
        {
            try
            {
                var bannerCompanies = _mapper.Map<List<BannerCompanyDto>>(_bannerCompanyRepository.GetBannerCompanies());
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                return Ok(bannerCompanies);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetBannerCompanies");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpPost("create")]
        [ProducesResponseType(200)]
        [ProducesResponseType(200)]
        public IActionResult CreateBannerCompany([FromBody] BannerCompanyDto bannerCompanyCreate)
        {
            try
            {
                var bannerCompanies = _bannerCompanyRepository.GetBannerCompanies()
                    .Where(bc => bc.BannerId == bannerCompanyCreate.BannerId && bc.CompanyId == bannerCompanyCreate.CompanyId).FirstOrDefault();
                var bannerCompanyEntity = _mapper.Map<BannerCompany>(bannerCompanyCreate);
                if (bannerCompanyCreate == null)
                {
                    return BadRequest(ModelState);
                }
                if (bannerCompanyEntity == null)
                {
                    ModelState.AddModelError("", "BannerCompany already exists");
                    return StatusCode(422, ModelState);
                }

                if (!_bannerCompanyRepository.CreateBannerCompany(bannerCompanyEntity))
                {
                    _logger.LogError("Failed to create BannerCompany");
                }

                if (!_bannerCompanyRepository.Save())
                {
                    _logger.LogError("Failed to save changes");
                }

                var createdBanner = _mapper.Map<BannerDto>(bannerCompanyEntity);
                _logger.LogInformation("BannerCompany created successfully");
                return Ok("BannerCompany created successfully");
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "CreateBannerCompany");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpPut("update")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult UpdateBannerCompany(int BannerId, int CompanyId, [FromBody] BannerCompanyDto updateBannerCompany)
        {
            try
            {
                if (updateBannerCompany == null)
                    return BadRequest(ModelState);
                if (BannerId != updateBannerCompany.BannerId || CompanyId != updateBannerCompany.CompanyId)
                    return BadRequest(ModelState);
                if (!ModelState.IsValid)
                    return BadRequest();
                var bannerCompanyMap = _mapper.Map<BannerCompany>(updateBannerCompany);

                if (!_bannerCompanyRepository.UpdateBannerCompany(bannerCompanyMap))
                {
                    ModelState.AddModelError("", "Something went wrong updating BannerCompany");
                    return StatusCode(500, ModelState);
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "UpdateBannerCompany");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpDelete("delete")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult DeleteBannerCompany(int BannerId, int CompanyId)
        {
            try
            {
                var bannerCompanyDelete = _bannerCompanyRepository.GetBannerCompanies(BannerId, CompanyId);
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                if (!_bannerCompanyRepository.DeleteBannerCompany(bannerCompanyDelete))
                    ModelState.AddModelError("", "Something went wrong deleting BannerCompany");
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "DeleteBannerCompany");
                return StatusCode(500, "Internal server error occurred");
            }
        }
    }
}