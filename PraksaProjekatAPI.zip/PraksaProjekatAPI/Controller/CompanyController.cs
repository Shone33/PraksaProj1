﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using PraksaProjekatAPI.Services;
using ErrorLoggingService = PraksaProjekatAPI.Services.ErrorLoggingService;

namespace PraksaProjekatAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyRepository _companyRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<CompanyController> _logger;
        private readonly ErrorLoggingService _errorLoggingService;

        public CompanyController(ICompanyRepository companyRepository, IMapper mapper, ILogger<CompanyController> logger, ErrorLoggingService errorLoggingService)
        {
            _companyRepository = companyRepository;
            _mapper = mapper;
            _logger = logger;
            _errorLoggingService = errorLoggingService;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<CompanyDto>))]
        public IActionResult GetCompanies()
        {
            try
            {
                var companies = _mapper.Map<List<CompanyDto>>(_companyRepository.GetCompanies());
                return Ok(companies);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetCompanies");
                return StatusCode(500, "An error occurred while fetching companies.");
            }
        }

        [HttpGet("{cId}")]
        [ProducesResponseType(200, Type = typeof(CompanyDto))]
        [ProducesResponseType(404)]
        public IActionResult GetCompany(int cId)
        {
            try
            {
                var company = _mapper.Map<CompanyDto>(_companyRepository.GetCompany(cId));
                if (company == null)
                {
                    return NotFound();
                }
                return Ok(company);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetCompany");
                return StatusCode(500, "An error occurred while fetching the company.");
            }
        }

        [HttpGet("banner/{bId}")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<BannerDto>))]
        [ProducesResponseType(404)]
        public IActionResult GetDynamicBannersByCompany(int bId)
        {
            try
            {
                var banners = _mapper.Map<List<BannerDto>>(_companyRepository.GetDynamicBannersByCompany(bId));
                if (!banners.Any())
                {
                    return NotFound();
                }
                return Ok(banners);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetDynamicBannersByCompany");
                return StatusCode(500, "An error occurred while fetching banners for the company.");
            }
        }

        [HttpPost("create")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public IActionResult CreateCompany([FromBody] CompanyDto companyCreate)
        {
            try
            {
                if (companyCreate == null)
                {
                    return BadRequest("Invalid company data");
                }

                var company = _companyRepository.GetCompanies()
                    .FirstOrDefault(c => c.Name.Trim().ToUpper() == companyCreate.Name.Trim().ToUpper());

                if (company != null)
                {
                    _logger.LogError("Failed to create company");
                    return Conflict("Company already exists");
                }

                var companyMap = _mapper.Map<Company>(companyCreate);

                if (!_companyRepository.CreateCompany(companyMap))
                {
                    _logger.LogError("Failed to save changes");
                    return BadRequest("Failed to create company");
                }

                _logger.LogInformation("Company created successfully");
                return CreatedAtAction(nameof(GetCompany), new { id = companyMap.Id }, companyMap);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "CreateCompany");
                return StatusCode(500, "An error occurred while creating the company.");
            }
        }

        [HttpPut("update")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult UpdateCompany(int cId, [FromBody] CompanyDto updateCompany)
        {
            try
            {
                if (updateCompany == null)
                {
                    return BadRequest("Invalid company data");
                }

                if (cId != updateCompany.Id)
                {
                    return BadRequest("Company id mismatch");
                }

                if (!_companyRepository.CompanyExists(cId))
                {
                    return NotFound("Company not found");
                }

                var companyMap = _mapper.Map<Company>(updateCompany);

                if (!_companyRepository.UpdateCompany(companyMap))
                {
                    _logger.LogError("Failed to save changes");
                    return BadRequest("Failed to update company");
                }

                _logger.LogInformation("Company updated successfully");
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "UpdateCompany");
                return StatusCode(500, "An error occurred while updating the company.");
            }
        }

        [HttpDelete("delete")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult DeleteCompany(int cId)
        {
            try
            {
                if (!_companyRepository.CompanyExists(cId))
                {
                    return NotFound("Company not found");
                }

                var companyDelete = _companyRepository.GetCompany(cId);

                if (!_companyRepository.DeleteCompany(companyDelete))
                {
                    _logger.LogError("Failed to delete company");
                    return BadRequest("Failed to delete company");
                }

                _logger.LogInformation("Company deleted successfully");
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "DeleteCompany");
                return StatusCode(500, "An error occurred while deleting the company.");
            }
        }
    }
}