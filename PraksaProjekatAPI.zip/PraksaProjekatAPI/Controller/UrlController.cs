﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using PraksaProjekatAPI.Services;
using ErrorLoggingService = PraksaProjekatAPI.Services.ErrorLoggingService;

namespace PraksaProjekatAPI.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class UrlController : ControllerBase
    {
        private readonly IUrlRepository _urlRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<UrlController> _logger;
        private readonly Services.ErrorLoggingService _errorLoggingService;

        public UrlController(IUrlRepository urlRepository, IMapper mapper, ILogger<UrlController> logger, ErrorLoggingService errorLoggingService)
        {
            _urlRepository = urlRepository;
            _mapper = mapper;
            _logger = logger;
            _errorLoggingService = errorLoggingService;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<UrlDto>))]
        public IActionResult GetUrls()
        {
            try
            {
                var urls = _mapper.Map<List<UrlDto>>(_urlRepository.GetUrls());
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                return Ok(urls);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetUrls");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpGet("{id}")]
        [ProducesResponseType(200, Type = typeof(UrlDto))]
        [ProducesResponseType(404)]
        public IActionResult GetUrl(int id)
        {
            try
            {
                if (!_urlRepository.UrlExists(id))
                    return NotFound();

                var url = _mapper.Map<UrlDto>(_urlRepository.GetUrl(id));
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                return Ok(url);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetUrl");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpGet("{id}/exists")]
        [ProducesResponseType(200, Type = typeof(bool))]
        public IActionResult UrlExists(int id)
        {
            try
            {
                var exists = _urlRepository.UrlExists(id);
                return Ok(exists);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "UrlExists");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpGet("byPath/{path}")]
        [ProducesResponseType(200, Type = typeof(UrlDto))]
        [ProducesResponseType(404)]
        public IActionResult GetUrlByPath(string path)
        {
            try
            {
                var url = _mapper.Map<UrlDto>(_urlRepository.GetUrlByPath(path));

                if (url == null)
                    return NotFound();

                return Ok(url);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetUrlByPath");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpGet("byImpDate/{date}")]
        [ProducesResponseType(200, Type = typeof(List<UrlDto>))]
        public IActionResult GetUrlsByImpDate(DateTime date)
        {
            try
            {
                var urls = _mapper.Map<List<UrlDto>>(_urlRepository.GetUrlsByImpDate(date));
                return Ok(urls);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetUrlsByImpDate");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpGet("byExpDate/{date}")]
        [ProducesResponseType(200, Type = typeof(List<UrlDto>))]
        public IActionResult GetUrlsByExpDate(DateTime date)
        {
            try
            {
                var urls = _mapper.Map<List<UrlDto>>(_urlRepository.GetUrlsByExpDate(date));
                return Ok(urls);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "GetUrlsByExpDate");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpPost("create")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public IActionResult CreateUrl([FromBody] UrlDto urlCreate)
        {
            try
            {
                if (urlCreate == null)
                {
                    return BadRequest("Invalid URL data");
                }

                var existingUrl = _urlRepository.GetUrlByPath(urlCreate.Path);
                if (existingUrl != null)
                {
                    _errorLoggingService.LogError("Error", "Failed to create url", "Path already exists", "CreateUrl");
                    return StatusCode(409, "Path already exists");
                }

                var urlMap = _mapper.Map<Url>(urlCreate);
                if (!_urlRepository.CreateUrl(urlMap))
                {
                    _errorLoggingService.LogError("Error", "Failed to save url", "", "CreateUrl");
                    return StatusCode(500, "Failed to save URL");
                }
                _logger.LogInformation("Company created successfully");
                return CreatedAtAction(nameof(GetUrl), new { id = urlMap.Id }, urlMap);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "CreateUrl");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpPut("update")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult UpdateUrl(int Id, [FromBody] UrlDto updateUrl)
        {
            try
            {
                if (updateUrl == null || Id != updateUrl.Id)
                {
                    return BadRequest("Invalid URL data");
                }

                if (!_urlRepository.UrlExists(Id))
                {
                    return NotFound();
                }

                var urlMap = _mapper.Map<Url>(updateUrl);
                if (!_urlRepository.UpdateUrl(urlMap))
                {
                    return StatusCode(500, "Failed to update URL");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "UpdateUrl");
                return StatusCode(500, "Internal server error occurred");
            }
        }

        [HttpDelete("delete")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult DeleteUrl(int Id)
        {
            try
            {
                if (!_urlRepository.UrlExists(Id))
                    return NotFound();
                var urlDelete = _urlRepository.GetUrl(Id);
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                if (!_urlRepository.DeleteUrl(urlDelete))
                    ModelState.AddModelError("", "Something went wrong deleting urls");
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, "DeleteUrl");
                return StatusCode(500, "Internal server error occurred");
            }
        }
    }
}