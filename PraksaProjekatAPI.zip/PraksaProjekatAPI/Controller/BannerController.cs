﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using PraksaProjekatAPI.Services;
using ErrorLoggingService = PraksaProjekatAPI.Services.ErrorLoggingService;

namespace PraksaProjekatAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BannerController : ControllerBase
    {
        private readonly IBannerRepository _bannerRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<BannerController> _logger;
        private readonly Services.ErrorLoggingService _errorLoggingService;

        public BannerController(IBannerRepository bannerRepository, IMapper mapper, ILogger<BannerController> logger, ErrorLoggingService errorLoggingService)
        {
            _bannerRepository = bannerRepository;
            _mapper = mapper;
            _logger = logger;
            _errorLoggingService = errorLoggingService;
        }
        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<DynamicBanners>))]
        public IActionResult GetBanners()
        {
            try
            {
                var banners = _mapper.Map<List<BannerDto>>(_bannerRepository.GetBanners());
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                return Ok(banners);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, ex.Source);
                return StatusCode(500, "An error occurred while processing your request. Please try again later.");
            }
        }

        [HttpGet("{bId}")]
        [ProducesResponseType(200, Type = typeof(DynamicBanners))]
        [ProducesResponseType(200)]
        public IActionResult GetBanners(int bId)
        {
            try
            {
                if (!_bannerRepository.DynamicBannerExists(bId))
                    return NotFound();

                var banners = _mapper.Map<BannerDto>(_bannerRepository.GetBanners(bId));
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                return Ok(banners);
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, ex.Source);
                return StatusCode(500, "An error occurred while processing your request. Please try again later.");
            }
        }
        [HttpPost("create")]
        [ProducesResponseType(200)]
        [ProducesResponseType(200)]
        public IActionResult CreateBanner([FromBody] BannerDto bannerCreate)
        {
            try
            {
                var banners = _bannerRepository.GetBanners()
                    .Where(b => b.Id == bannerCreate.Id).FirstOrDefault();
                var bannerEntity = _mapper.Map<DynamicBanners>(bannerCreate);
                if (bannerCreate == null)
                {
                    return BadRequest(ModelState);
                }
                if (bannerEntity == null)
                {
                    ModelState.AddModelError("", "Banner already exists");
                }

                if (!_bannerRepository.CreateBanner(bannerEntity))
                {
                    _errorLoggingService.LogError("Error", "Failed to create banner");
                }

                if (!_bannerRepository.Save())
                {
                    _errorLoggingService.LogError("Error", "Failed to save changes");
                }

                var createdBanner = _mapper.Map<BannerDto>(bannerEntity);
                _logger.LogInformation("Banner created successfully");
                return Ok("Banner created successfully");
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, ex.Source);
                return StatusCode(500, "An error occurred while processing your request. Please try again later.");
            }
        }
        [HttpPut("update")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult UpdateBanner(int bId, [FromBody] BannerDto updateBanner)
        {
            try
            {
                if (updateBanner == null || bId != updateBanner.Id)
                    return BadRequest(ModelState);

                if (!_bannerRepository.DynamicBannerExists(bId))
                    return NotFound();

                if (!ModelState.IsValid)
                    return BadRequest();

                var bannerMap = _mapper.Map<DynamicBanners>(updateBanner);

                if (!_bannerRepository.UpdateBanner(bannerMap))
                {
                    ModelState.AddModelError("", "Something went wrong updating banners");
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, ex.Source);
                return StatusCode(500, "An error occurred while processing your request. Please try again later.");
            }
        }
        [HttpDelete("delete")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult DeleteBanner(int bId)
        {
            try
            {
                if (!_bannerRepository.DynamicBannerExists(bId))
                    return NotFound();

                var bannerDelete = _bannerRepository.GetBanners(bId);
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (!_bannerRepository.DeleteBanner(bannerDelete))
                    ModelState.AddModelError("", "Something went wrong deleting banners");

                return NoContent();
            }
            catch (Exception ex)
            {
                _errorLoggingService.LogError("Error", ex.Message, ex.StackTrace, ex.Source);
                return StatusCode(500, "An error occurred while processing your request. Please try again later.");
            }
        }
    }
}
