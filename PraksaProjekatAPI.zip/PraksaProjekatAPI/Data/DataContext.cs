﻿using Microsoft.EntityFrameworkCore;
using PraksaProjekatAPI.Models;
using System.Data;

namespace PraksaProjekatAPI.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }
        public DbSet<DynamicBanners> DynamicBanners { get; set; }
        public DbSet<Company> Company { get; set; }
        public DbSet<Url> Urls { get; set; }
        public DbSet<BannerCompany> BannerCompanies { get; set; }

        public DbSet<ErrorLog> ErrorLogs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Accessing connection string from IConfiguration
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();

                var connectionString = configuration.GetConnectionString("DefaultConnection");

                optionsBuilder.UseSqlServer(connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DynamicBanners>()
                .HasKey(db => db.Id);

            modelBuilder.Entity<DynamicBanners>()
                .HasMany(db => db.Urls)
                .WithOne(u => u.DynamicBanners)
                .HasForeignKey(u => u.DynamicBannersId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Company>()
                .HasKey(c => c.Id);

            modelBuilder.Entity<Company>()
                .HasOne(c => c.DynamicBanners)
                .WithOne(db => db.Company)
                .HasForeignKey<Company>(c => c.DynamicBannersId)
                .IsRequired();

            modelBuilder.Entity<Company>()
                .HasMany(c => c.Urls)
                .WithOne(u => u.Company)
                .HasForeignKey(u => u.CompanyId)
                .IsRequired();

            modelBuilder.Entity<BannerCompany>()
                .HasKey(bc => new { bc.BannerId, bc.CompanyId });

            modelBuilder.Entity<BannerCompany>()
                .HasOne(bc => bc.DynamicBanners)
                .WithMany(db => db.BannerCompanies)
                .HasForeignKey(bc => bc.BannerId);

            modelBuilder.Entity<BannerCompany>()
                .HasOne(bc => bc.Company)
                .WithMany(c => c.BannerCompanies)
                .HasForeignKey(bc => bc.CompanyId);
            modelBuilder.Entity<Url>()
                    .HasKey(u => u.Id);
            modelBuilder.Entity<Url>()
                .HasOne(u => u.DynamicBanners)
                .WithMany(db => db.Urls)
                .HasForeignKey(u => u.DynamicBannersId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Url>()
                .HasOne(u => u.Company)
                .WithMany(c => c.Urls)
                .HasForeignKey(u => u.CompanyId)
                .OnDelete(DeleteBehavior.Restrict);
            base.OnModelCreating(modelBuilder);
        }
    }
}