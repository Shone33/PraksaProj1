﻿using System.ComponentModel.DataAnnotations;

namespace PraksaProjekatAPI.Models
{
    public class Company
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public DynamicBanners DynamicBanners { get; set; }
        public int DynamicBannersId { get; set; }
        public List<Url> Urls { get; set; }
        public List<BannerCompany> BannerCompanies { get; set; }


    }
}
