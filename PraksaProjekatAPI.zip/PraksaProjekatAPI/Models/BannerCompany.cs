﻿using System.ComponentModel.DataAnnotations;

namespace PraksaProjekatAPI.Models
{
    public class BannerCompany
    {
        [Key]
        public int BannerId { get; set; }
        [Key]
        public int CompanyId { get; set; }
        public DynamicBanners DynamicBanners { get; set; }
        public Company Company { get; set; }
    }
}