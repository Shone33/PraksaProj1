﻿using Microsoft.EntityFrameworkCore;

namespace PraksaProjekatAPI.Models
{
    public class ErrorLog
    {
        public int Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string LogLevel { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
    }

    public class DataContext : DbContext
    {
        public DbSet<ErrorLog> ErrorLogs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();

                string connectionString = configuration.GetConnectionString("DefaultConnection");
                optionsBuilder.UseSqlServer(connectionString);
            }
        }
    }

    public class ErrorLoggingService
    {
        private readonly DataContext _context;

        public ErrorLoggingService(DataContext context)
        {
            _context = context;
        }

        public void LogError(string logLevel, string message, string stackTrace = null, string source = null)
        {
            var errorLog = new ErrorLog
            {
                Timestamp = DateTime.Now,
                LogLevel = logLevel,
                Message = message,
                StackTrace = stackTrace,
                Source = source
            };

            _context.ErrorLogs.Add(errorLog);
            _context.SaveChanges();
        }
    }
}
