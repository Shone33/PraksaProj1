﻿using System.ComponentModel.DataAnnotations;

namespace PraksaProjekatAPI.Models
{
    public class Url
    {
        [Key]
        public int Id { get; set; }
        public DateTime ImpDate { get; set; }
        public DateTime ExpDate { get; set; }

        public string Path { get; set; }
        public string BName { get; set; }
        public int DynamicBannersId { get; set; }
        public DynamicBanners DynamicBanners { get; set; }
        public int CompanyId { get; set; }
        public Company Company { get; set; }

    }
}
