﻿using System.ComponentModel.DataAnnotations;

namespace PraksaProjekatAPI.Models
{
    public class DynamicBanners
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public List<Url> Urls { get; set; }
        public Company Company { get; set; }
        public List<BannerCompany> BannerCompanies { get; set; }
    }
}
