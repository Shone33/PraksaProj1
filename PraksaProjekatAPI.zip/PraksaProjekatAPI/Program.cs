using BannerApp;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Repository;
using PraksaProjekatAPI.Services;
using System;
using System.Text.Json.Serialization;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Logging.ClearProviders();
        builder.Logging.AddLog4Net();
        builder.Services.AddControllers();
        builder.Services.AddTransient<Seed>();
        builder.Services.AddControllers().AddJsonOptions(x => x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);
        builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        builder.Services.AddScoped<IBannerRepository, BannerRepositories>();
        builder.Services.AddScoped<ICompanyRepository, CompanyRepositories>();
        builder.Services.AddScoped<IUrlRepository, UrlRepositories>();
        builder.Services.AddScoped<IBannerCompanyRepository, BannerCompanyRepositories>();

        // Configure DbContext
        builder.Services.AddDbContext<DataContext>(options =>
        {
            // Use connection string from appsettings.json
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            options.UseSqlServer(connectionString);
        });

        // Configure Swagger
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        ConfigureServices(builder.Services, builder.Configuration);

        var app = builder.Build();

        if (args.Length == 1 && args[0].ToLower() == "seeddata")
            SeedData(app);

        void SeedData(IHost app)
        {
            var scopedFactory = app.Services.GetService<IServiceScopeFactory>();

            using (var scope = scopedFactory.CreateScope())
            {
                var service = scope.ServiceProvider.GetService<Seed>();
                service.SeedDataContext();
            }
        }

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }

    private static void ConfigureServices(IServiceCollection services, IConfiguration configuration)
    {
        // Add services
        services.AddScoped<ErrorLoggingService>();

        // Add AutoMapper
        services.AddAutoMapper(typeof(Program));

        // Add other services as needed
    }
}
