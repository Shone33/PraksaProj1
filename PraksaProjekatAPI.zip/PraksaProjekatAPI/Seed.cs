﻿using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using DataContext = PraksaProjekatAPI.Data.DataContext;

namespace BannerApp
{
    public class Seed
    {
        private readonly DataContext dataContext;

        public Seed(DataContext context)
        {
            this.dataContext = context;
        }

        public void SeedDataContext()
        {
            if (!dataContext.DynamicBanners.Any())
            {
                var dynamicBanners = new List<DynamicBanners>
                {
                    new DynamicBanners { Name = "Banner1", Type = "Type1" },
                    new DynamicBanners { Name = "Banner2", Type = "Type2" },
                    // Add more DynamicBanners as needed
                };

                var companies = new List<Company>
                {
                    new Company { Name = "Company1" },
                    new Company { Name = "Company2" },
                    // Add more companies as needed
                };

                var urls = new List<Url>
                {
                     new Url { Id = 12, Path = "Path1", },
                     new Url { Id = 11, Path = "Path2", }
                };

                var bannerCompanies = new List<BannerCompany>
                {
                    new BannerCompany { CompanyId = 1, DynamicBanners = dynamicBanners[0] },
                    new BannerCompany { CompanyId = 2, DynamicBanners = dynamicBanners[1] },
                    // Add more BannerCompanies as needed
                };

                dataContext.DynamicBanners.AddRange(dynamicBanners);
                dataContext.Company.AddRange(companies);
                dataContext.Urls.AddRange(urls);
                dataContext.BannerCompanies.AddRange(bannerCompanies);

                dataContext.SaveChanges();
            }
        }
    }
}