﻿using System.ComponentModel.DataAnnotations;
namespace PraksaProjekatAPI.Dto
{
    public class UrlDto
    {
        public int Id { get; set; }
        public DateTime ImpDate { get; set; }
        public DateTime ExpDate { get; set; }
        public string Path { get; set; }
        public string BName { get; set; }
        public int DynamicBannersId { get; set; }
        public int CompanyId { get; set; }
    }
}
