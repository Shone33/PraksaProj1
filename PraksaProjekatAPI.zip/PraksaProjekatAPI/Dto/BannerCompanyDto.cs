﻿namespace PraksaProjekatAPI.Dto
{
    public class BannerCompanyDto
    {
        public int BannerId { get; set; }
        public int CompanyId { get; set; }
    }
}
