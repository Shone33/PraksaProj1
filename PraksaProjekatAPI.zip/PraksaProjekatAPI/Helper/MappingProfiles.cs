﻿using AutoMapper;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Models;

namespace PraksaProjekatAPI.Helper
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<DynamicBanners, BannerDto>();
            CreateMap<BannerDto, DynamicBanners>();
            CreateMap<Company, CompanyDto>();
            CreateMap<CompanyDto, Company>();
            CreateMap<Url, UrlDto>();
            CreateMap<UrlDto, Url>();
            CreateMap<BannerCompany, BannerCompanyDto>();
            CreateMap<BannerCompanyDto, BannerCompany>();
        }
    }
}
