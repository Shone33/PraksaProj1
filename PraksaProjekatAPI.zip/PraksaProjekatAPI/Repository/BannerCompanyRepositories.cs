﻿using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using System.ComponentModel.Design;
using DataContext = PraksaProjekatAPI.Data.DataContext;

namespace PraksaProjekatAPI.Repository
{
    public class BannerCompanyRepositories : IBannerCompanyRepository
    {

        private readonly DataContext _context;
        public BannerCompanyRepositories(DataContext context)
        {
            _context = context;
        }

        public bool CreateBannerCompany(BannerCompany bannerCompany)
        {
            try
            {
                var bannerCompanyEntity = _context.BannerCompanies.FirstOrDefault(a => a.BannerId == bannerCompany.BannerId && a.CompanyId == bannerCompany.CompanyId);

                if (bannerCompanyEntity == null)
                {
                    _context.BannerCompanies.Add(bannerCompany);
                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception during CreateBannerCompany: {ex.Message}");
                return false;
            }
        }

        public bool DeleteBannerCompany(BannerCompany bannerCompany)
        {
            _context.Remove(bannerCompany);
            return Save();
        }

        public ICollection<BannerCompany> GetBannerCompanies()
        {
            return _context.BannerCompanies.OrderBy(d => d.BannerId).ToList();
        }

        public BannerCompany GetBannerCompanies(int BannerId, int CompanyId)
        {
            return _context.BannerCompanies
                .FirstOrDefault(bc => bc.BannerId == BannerId && bc.CompanyId == CompanyId);
        }

        public bool UpdateBannerCompany(BannerCompany bannerCompany)
        {
            _context.Update(bannerCompany);
            return Save();
        }
        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }
    }
}
