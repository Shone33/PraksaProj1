﻿using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using System.ComponentModel;
using DataContext = PraksaProjekatAPI.Data.DataContext;

namespace PraksaProjekatAPI.Repository
{
    public class CompanyRepositories : ICompanyRepository
    {
        private readonly DataContext _context;
        public CompanyRepositories(DataContext context)
        {
            _context = context;
        }
        public bool CompanyExists(int id)
        {
           return _context.Company.Any(c => c.Id == id);
        }

        public Company GetCompany(int id)
        {
            return _context.Company.Where(c => c.Id == id).FirstOrDefault();
        }

        public ICollection<Company> GetCompanies()
        {
            return _context.Company.ToList();
        }

        public ICollection<DynamicBanners> GetDynamicBannersByCompany(int cId)
        {
            return _context.BannerCompanies.Where(c => c.CompanyId == cId).Select(c => c.DynamicBanners).ToList();
        }

        public bool CreateCompany(Company company)
        {
            _context.Add(company);
            return Save();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateCompany(Company company)
        {
            _context.Update(company);
            return Save();
        }

        public bool DeleteCompany(Company company)
        {
            _context.Remove(company);
            return Save();
        }
    }
}
