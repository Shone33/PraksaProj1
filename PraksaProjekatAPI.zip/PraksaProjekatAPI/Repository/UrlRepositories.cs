﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Dto;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using System.Security.Cryptography;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using DataContext = PraksaProjekatAPI.Data.DataContext;

namespace PraksaProjekatAPI.Repository
{
    public class UrlRepositories : IUrlRepository
    {
        private readonly DataContext _context;

        public UrlRepositories(DataContext context)
        {
            _context = context;
        }

        public bool UrlExists(int id)
        {
            return _context.Urls.Any(u => u.Id == id);
        }

        public Url GetUrl(int id)
        {
            return _context.Urls.Where(u => u.Id == id).FirstOrDefault();
        }

        public Url GetBannerByUrl(int uId)
        {
            return _context.Urls.Where(u => u.DynamicBannersId == uId).FirstOrDefault();
        }

        public Url GetUrlByPath(string path)
        {
            return _context.Urls.FirstOrDefault(u => u.Path == path);
        }

        public ICollection<Url> GetUrls()
        {
            return _context.Urls.ToList();

        }

        public List<Url> GetUrlsByImpDate(DateTime date)
        {
            return _context.Urls.Where(u => u.ImpDate == date).ToList();
        }

        public List<Url> GetUrlsByExpDate(DateTime date)
        {
            return _context.Urls.Where(u => u.ExpDate == date).ToList();
        }

        public bool CreateUrl(Url url)
        {
            _context.Add(url);
            return Save();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateUrl(Url url)
        {
            _context.Update(url);
            return Save();
        }

        public bool DeleteUrl(Url url)
        {
            _context.Remove(url);
            return Save();
        }
    }
}
