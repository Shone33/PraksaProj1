﻿using PraksaProjekatAPI.Data;
using PraksaProjekatAPI.Interfaces;
using PraksaProjekatAPI.Models;
using System.Reflection;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using DataContext = PraksaProjekatAPI.Data.DataContext;

namespace PraksaProjekatAPI.Repository
{
    public class BannerRepositories : IBannerRepository
    {
        private readonly DataContext _context;
        public BannerRepositories(DataContext context)
        {
           _context = context;
        }

        public bool CreateBanner(DynamicBanners dynamicBanners)
        {
            try
            {
                var bannerEntity = _context.DynamicBanners.FirstOrDefault(a => a.Id == dynamicBanners.Id);

                if (bannerEntity == null)
                {
                    _context.DynamicBanners.Add(dynamicBanners);
                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception during CreateBanner: {ex.Message}");
                return false;
            }
        }

        public bool DeleteBanner(DynamicBanners dynamicBanners)
        {
            _context.Remove(dynamicBanners);
            return Save();
        }

        public bool DynamicBannerExists(int Id)
        {
            return _context.DynamicBanners.Any(d => d.Id == Id);
        }

        public ICollection<DynamicBanners> GetBanners()
        {
            return _context.DynamicBanners.OrderBy(d => d.Id).ToList();
        }

        public DynamicBanners GetBanners(int id)
        {
            return _context.DynamicBanners.Where(d => d.Id == id).FirstOrDefault();
        }

        public DynamicBanners GetBanners(string name)
        {
            return _context.DynamicBanners.Where(d => d.Name == name).FirstOrDefault();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateBanner(DynamicBanners dynamicBanners)
        {
            _context.Update(dynamicBanners);
            return Save();
        }
    }
}
