﻿using PraksaProjekatAPI.Models;

namespace PraksaProjekatAPI.Services
{
    public class ErrorLoggingService
    {
        private readonly DataContext _context;

        public ErrorLoggingService(DataContext context)
        {
            _context = context;
        }

        public void LogError(string logLevel, string message, string stackTrace = null, string source = null)
        {
            var errorLog = new ErrorLog
            {
                Timestamp = DateTime.Now,
                LogLevel = logLevel,
                Message = message,
                StackTrace = stackTrace,
                Source = source
            };

            _context.ErrorLogs.Add(errorLog);
            _context.SaveChanges();
        }
    }
}
