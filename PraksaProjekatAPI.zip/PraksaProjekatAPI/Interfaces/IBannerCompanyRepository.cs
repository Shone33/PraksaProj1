﻿using PraksaProjekatAPI.Models;

namespace PraksaProjekatAPI.Interfaces
{
    public interface IBannerCompanyRepository
    {
        ICollection<BannerCompany> GetBannerCompanies();
        BannerCompany GetBannerCompanies(int BannerId, int CompanyId);
        bool CreateBannerCompany(BannerCompany bannerCompany);
        bool UpdateBannerCompany(BannerCompany bannerCompany);
        bool DeleteBannerCompany(BannerCompany bannerCompany);
        bool Save();
    }
}
