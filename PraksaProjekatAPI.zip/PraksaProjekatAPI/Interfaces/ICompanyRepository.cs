﻿using PraksaProjekatAPI.Models;
using System.ComponentModel;

namespace PraksaProjekatAPI.Interfaces
{
    public interface ICompanyRepository
    {
        ICollection<Company> GetCompanies();
        Company GetCompany(int id);
        ICollection<DynamicBanners> GetDynamicBannersByCompany(int cId);
        bool CompanyExists(int id);
        bool CreateCompany(Company company);
        bool UpdateCompany(Company company);
        bool DeleteCompany( Company company);
        bool Save();
    }
}
