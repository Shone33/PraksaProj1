﻿namespace PraksaProjekatAPI.Interfaces
{
    public interface IBannerCompanyRepository
    {
    }
}
