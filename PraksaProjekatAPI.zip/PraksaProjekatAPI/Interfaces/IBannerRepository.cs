﻿using PraksaProjekatAPI.Models;

namespace PraksaProjekatAPI.Interfaces
{
    public interface IBannerRepository
    {
        ICollection<DynamicBanners> GetBanners();
        DynamicBanners GetBanners(int id);
        DynamicBanners GetBanners(string name);
        bool DynamicBannerExists(int bId);
        bool CreateBanner(DynamicBanners dynamicBanners);
        bool UpdateBanner(DynamicBanners dynamicBanners);
        bool DeleteBanner(DynamicBanners dynamicBanners);
        bool Save();
    }
}
