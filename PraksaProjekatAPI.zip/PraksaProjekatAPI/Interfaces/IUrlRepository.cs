﻿using PraksaProjekatAPI.Models;

namespace PraksaProjekatAPI.Interfaces
{
    public interface IUrlRepository
    {
        ICollection<Url> GetUrls();
        Url GetUrl(int id);
        Url GetUrlByPath(string path);
        Url GetBannerByUrl(int uId);
        List<Url> GetUrlsByImpDate(DateTime date);

        List<Url> GetUrlsByExpDate(DateTime date);
        bool UrlExists(int id);
        bool CreateUrl(Url url);
        bool UpdateUrl (Url url);
        bool DeleteUrl(Url url);
        bool Save();
    }
}
